import { useState } from "react";
import { format, isAfter, isBefore, addDays } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { DatePicker } from "@/components/ui/date-picker";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Calendar, Clock, Edit, Trash2, CheckCircle, XCircle, ArrowDownCircle, ArrowUpCircle } from "lucide-react";

interface StudyTask {
  id: number;
  title: string;
  description: string;
  dueDate: Date;
  completed: boolean;
  priority: 'high' | 'medium' | 'low';
  category: string;
}

export function StudyPlanner() {
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<StudyTask | null>(null);
  const [newTask, setNewTask] = useState<Partial<StudyTask>>({
    title: '',
    description: '',
    dueDate: new Date(),
    completed: false,
    priority: 'medium',
    category: 'General'
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Temporarily using a mock data array for development
  // This would be replaced with actual API calls in production
  const [studyTasks, setStudyTasks] = useState<StudyTask[]>([
    {
      id: 1,
      title: "Review Biology Chapter 5",
      description: "Read chapter 5 on cellular respiration and take notes",
      dueDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000), // 3 days from now
      completed: false,
      priority: 'high',
      category: 'Biology'
    },
    {
      id: 2,
      title: "Math Problem Set 3",
      description: "Complete problems 1-20 on integration techniques",
      dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // 2 days from now
      completed: false,
      priority: 'medium',
      category: 'Math'
    },
    {
      id: 3,
      title: "History Essay Research",
      description: "Find sources for essay on French Revolution",
      dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000), // 5 days from now
      completed: true,
      priority: 'low',
      category: 'History'
    },
    {
      id: 4,
      title: "Chemistry Lab Preparation",
      description: "Review lab protocol and safety procedures",
      dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000), // 1 day from now
      completed: false,
      priority: 'high',
      category: 'Chemistry'
    }
  ]);

  // In a real implementation, these would be API calls
  const addTask = (task: Partial<StudyTask>) => {
    const newTaskWithId: StudyTask = {
      ...task as any,
      id: Math.max(0, ...studyTasks.map(t => t.id)) + 1,
      completed: false
    };
    setStudyTasks([...studyTasks, newTaskWithId]);
    toast({
      title: "Task added",
      description: "Your study task has been added to your planner."
    });
  };

  const updateTask = (id: number, updates: Partial<StudyTask>) => {
    const updatedTasks = studyTasks.map(task => 
      task.id === id ? { ...task, ...updates } : task
    );
    setStudyTasks(updatedTasks);
    toast({
      title: "Task updated",
      description: "Your study task has been updated."
    });
  };

  const deleteTask = (id: number) => {
    setStudyTasks(studyTasks.filter(task => task.id !== id));
    toast({
      title: "Task deleted",
      description: "Your study task has been removed from your planner."
    });
  };

  const toggleTaskCompletion = (id: number) => {
    const taskToToggle = studyTasks.find(task => task.id === id);
    if (taskToToggle) {
      updateTask(id, { completed: !taskToToggle.completed });
    }
  };

  const handleAddTask = () => {
    addTask(newTask);
    setNewTask({
      title: '',
      description: '',
      dueDate: new Date(),
      completed: false,
      priority: 'medium',
      category: 'General'
    });
    setIsAddDialogOpen(false);
  };

  const handleEditTask = () => {
    if (selectedTask) {
      updateTask(selectedTask.id, selectedTask);
      setSelectedTask(null);
      setIsEditDialogOpen(false);
    }
  };

  const openEditDialog = (task: StudyTask) => {
    setSelectedTask({ ...task });
    setIsEditDialogOpen(true);
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Group tasks by category
  const tasksByCategory = studyTasks.reduce((acc, task) => {
    if (!acc[task.category]) {
      acc[task.category] = [];
    }
    acc[task.category].push(task);
    return acc;
  }, {} as Record<string, StudyTask[]>);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Study Planner</h2>
        <Button onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="h-4 w-4 mr-2" /> Add Task
        </Button>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Tasks</TabsTrigger>
          <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="by-category">By Category</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-0">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {studyTasks.length > 0 ? (
              studyTasks.map(task => (
                <Card key={task.id} className={task.completed ? "opacity-70" : ""}>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <div className="flex items-center space-x-2">
                        <Checkbox 
                          checked={task.completed}
                          onCheckedChange={() => toggleTaskCompletion(task.id)}
                          className="h-5 w-5"
                        />
                        <CardTitle className={`text-base ${task.completed ? "line-through text-gray-500" : ""}`}>
                          {task.title}
                        </CardTitle>
                      </div>
                      <Badge variant="outline" className={getPriorityColor(task.priority)}>
                        {task.priority}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-3">{task.description}</p>
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span>{format(task.dueDate, "MMM d, yyyy")}</span>
                      </div>
                      <div className="flex space-x-2">
                        <button 
                          onClick={() => openEditDialog(task)}
                          className="text-gray-500 hover:text-gray-700"
                        >
                          <Edit className="h-4 w-4" />
                        </button>
                        <button 
                          onClick={() => deleteTask(task.id)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-full flex flex-col items-center justify-center py-12 text-center">
                <div className="rounded-full bg-gray-100 p-3 mb-4">
                  <Calendar className="h-6 w-6 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">No tasks yet</h3>
                <p className="text-gray-500 max-w-md mt-2 mb-6">
                  Start by adding your first study task to plan your learning.
                </p>
                <Button onClick={() => setIsAddDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" /> Add Your First Task
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="upcoming" className="mt-0">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {studyTasks.filter(task => !task.completed && isAfter(task.dueDate, new Date())).length > 0 ? (
              studyTasks
                .filter(task => !task.completed && isAfter(task.dueDate, new Date()))
                .sort((a, b) => a.dueDate.getTime() - b.dueDate.getTime())
                .map(task => (
                  <Card key={task.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            checked={task.completed}
                            onCheckedChange={() => toggleTaskCompletion(task.id)}
                            className="h-5 w-5"
                          />
                          <CardTitle className="text-base">
                            {task.title}
                          </CardTitle>
                        </div>
                        <Badge variant="outline" className={getPriorityColor(task.priority)}>
                          {task.priority}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600 mb-3">{task.description}</p>
                      <div className="flex justify-between items-center text-xs text-gray-500">
                        <div className="flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          <span>{format(task.dueDate, "MMM d, yyyy")}</span>
                        </div>
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => openEditDialog(task)}
                            className="text-gray-500 hover:text-gray-700"
                          >
                            <Edit className="h-4 w-4" />
                          </button>
                          <button 
                            onClick={() => deleteTask(task.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
            ) : (
              <div className="col-span-full flex flex-col items-center justify-center py-12 text-center">
                <div className="rounded-full bg-gray-100 p-3 mb-4">
                  <CheckCircle className="h-6 w-6 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">No upcoming tasks</h3>
                <p className="text-gray-500 max-w-md mt-2 mb-6">
                  You don't have any upcoming tasks to complete.
                </p>
                <Button onClick={() => setIsAddDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" /> Add Task
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="completed" className="mt-0">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {studyTasks.filter(task => task.completed).length > 0 ? (
              studyTasks
                .filter(task => task.completed)
                .map(task => (
                  <Card key={task.id} className="opacity-70">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center space-x-2">
                          <Checkbox 
                            checked={task.completed}
                            onCheckedChange={() => toggleTaskCompletion(task.id)}
                            className="h-5 w-5"
                          />
                          <CardTitle className="text-base line-through text-gray-500">
                            {task.title}
                          </CardTitle>
                        </div>
                        <Badge variant="outline" className={getPriorityColor(task.priority)}>
                          {task.priority}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600 mb-3">{task.description}</p>
                      <div className="flex justify-between items-center text-xs text-gray-500">
                        <div className="flex items-center">
                          <Calendar className="h-3 w-3 mr-1" />
                          <span>{format(task.dueDate, "MMM d, yyyy")}</span>
                        </div>
                        <div className="flex space-x-2">
                          <button 
                            onClick={() => deleteTask(task.id)}
                            className="text-red-500 hover:text-red-700"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))
            ) : (
              <div className="col-span-full flex flex-col items-center justify-center py-12 text-center">
                <div className="rounded-full bg-gray-100 p-3 mb-4">
                  <XCircle className="h-6 w-6 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900">No completed tasks</h3>
                <p className="text-gray-500 max-w-md mt-2 mb-6">
                  You haven't completed any tasks yet. Start by checking off your completed work.
                </p>
                <Button onClick={() => setIsAddDialogOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" /> Add Task
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="by-category" className="mt-0">
          {Object.keys(tasksByCategory).length > 0 ? (
            Object.entries(tasksByCategory).map(([category, tasks]) => (
              <div key={category} className="mb-8">
                <h3 className="text-lg font-semibold mb-4">{category}</h3>
                <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                  {tasks.map(task => (
                    <Card key={task.id} className={task.completed ? "opacity-70" : ""}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <div className="flex items-center space-x-2">
                            <Checkbox 
                              checked={task.completed}
                              onCheckedChange={() => toggleTaskCompletion(task.id)}
                              className="h-5 w-5"
                            />
                            <CardTitle className={`text-base ${task.completed ? "line-through text-gray-500" : ""}`}>
                              {task.title}
                            </CardTitle>
                          </div>
                          <Badge variant="outline" className={getPriorityColor(task.priority)}>
                            {task.priority}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-sm text-gray-600 mb-3">{task.description}</p>
                        <div className="flex justify-between items-center text-xs text-gray-500">
                          <div className="flex items-center">
                            <Calendar className="h-3 w-3 mr-1" />
                            <span>{format(task.dueDate, "MMM d, yyyy")}</span>
                          </div>
                          <div className="flex space-x-2">
                            <button 
                              onClick={() => openEditDialog(task)}
                              className="text-gray-500 hover:text-gray-700"
                            >
                              <Edit className="h-4 w-4" />
                            </button>
                            <button 
                              onClick={() => deleteTask(task.id)}
                              className="text-red-500 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            ))
          ) : (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <div className="rounded-full bg-gray-100 p-3 mb-4">
                <Calendar className="h-6 w-6 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900">No tasks yet</h3>
              <p className="text-gray-500 max-w-md mt-2 mb-6">
                Start by adding your first study task to plan your learning.
              </p>
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" /> Add Your First Task
              </Button>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Add Task Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Add Study Task</DialogTitle>
            <DialogDescription>
              Create a new task for your study plan.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <label htmlFor="title" className="text-sm font-medium">
                Task Title
              </label>
              <Input
                id="title"
                placeholder="e.g., Read Chapter 5"
                value={newTask.title}
                onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="description" className="text-sm font-medium">
                Description (optional)
              </label>
              <Textarea
                id="description"
                placeholder="Add more details about your task"
                value={newTask.description}
                onChange={(e) => setNewTask({ ...newTask, description: e.target.value })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="category" className="text-sm font-medium">
                  Category
                </label>
                <Select 
                  value={newTask.category}
                  onValueChange={(value) => setNewTask({ ...newTask, category: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="General">General</SelectItem>
                    <SelectItem value="Math">Math</SelectItem>
                    <SelectItem value="Science">Science</SelectItem>
                    <SelectItem value="History">History</SelectItem>
                    <SelectItem value="English">English</SelectItem>
                    <SelectItem value="Biology">Biology</SelectItem>
                    <SelectItem value="Chemistry">Chemistry</SelectItem>
                    <SelectItem value="Physics">Physics</SelectItem>
                    <SelectItem value="Computer Science">Computer Science</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label htmlFor="priority" className="text-sm font-medium">
                  Priority
                </label>
                <Select 
                  value={newTask.priority}
                  onValueChange={(value: any) => setNewTask({ ...newTask, priority: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select priority" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="high">
                      <div className="flex items-center">
                        <ArrowUpCircle className="h-4 w-4 mr-2 text-red-500" />
                        High
                      </div>
                    </SelectItem>
                    <SelectItem value="medium">
                      <div className="flex items-center">
                        <div className="h-4 w-4 mr-2 rounded-full bg-yellow-500" />
                        Medium
                      </div>
                    </SelectItem>
                    <SelectItem value="low">
                      <div className="flex items-center">
                        <ArrowDownCircle className="h-4 w-4 mr-2 text-green-500" />
                        Low
                      </div>
                    </SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="due-date" className="text-sm font-medium">
                Due Date
              </label>
              <DatePicker 
                date={newTask.dueDate} 
                setDate={(date) => setNewTask({ ...newTask, dueDate: date })}
              />
            </div>
          </div>
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleAddTask}
              disabled={!newTask.title}
            >
              Add Task
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Task Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Edit Study Task</DialogTitle>
            <DialogDescription>
              Update the details of your study task.
            </DialogDescription>
          </DialogHeader>
          {selectedTask && (
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <label htmlFor="edit-title" className="text-sm font-medium">
                  Task Title
                </label>
                <Input
                  id="edit-title"
                  value={selectedTask.title}
                  onChange={(e) => setSelectedTask({ ...selectedTask, title: e.target.value })}
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="edit-description" className="text-sm font-medium">
                  Description
                </label>
                <Textarea
                  id="edit-description"
                  value={selectedTask.description}
                  onChange={(e) => setSelectedTask({ ...selectedTask, description: e.target.value })}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label htmlFor="edit-category" className="text-sm font-medium">
                    Category
                  </label>
                  <Select 
                    value={selectedTask.category}
                    onValueChange={(value) => setSelectedTask({ ...selectedTask, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="General">General</SelectItem>
                      <SelectItem value="Math">Math</SelectItem>
                      <SelectItem value="Science">Science</SelectItem>
                      <SelectItem value="History">History</SelectItem>
                      <SelectItem value="English">English</SelectItem>
                      <SelectItem value="Biology">Biology</SelectItem>
                      <SelectItem value="Chemistry">Chemistry</SelectItem>
                      <SelectItem value="Physics">Physics</SelectItem>
                      <SelectItem value="Computer Science">Computer Science</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label htmlFor="edit-priority" className="text-sm font-medium">
                    Priority
                  </label>
                  <Select 
                    value={selectedTask.priority}
                    onValueChange={(value: any) => setSelectedTask({ ...selectedTask, priority: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="high">
                        <div className="flex items-center">
                          <ArrowUpCircle className="h-4 w-4 mr-2 text-red-500" />
                          High
                        </div>
                      </SelectItem>
                      <SelectItem value="medium">
                        <div className="flex items-center">
                          <div className="h-4 w-4 mr-2 rounded-full bg-yellow-500" />
                          Medium
                        </div>
                      </SelectItem>
                      <SelectItem value="low">
                        <div className="flex items-center">
                          <ArrowDownCircle className="h-4 w-4 mr-2 text-green-500" />
                          Low
                        </div>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <label htmlFor="edit-due-date" className="text-sm font-medium">
                  Due Date
                </label>
                <DatePicker 
                  date={selectedTask.dueDate} 
                  setDate={(date) => setSelectedTask({ ...selectedTask, dueDate: date })}
                />
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox 
                  id="edit-completed"
                  checked={selectedTask.completed}
                  onCheckedChange={(checked) => 
                    setSelectedTask({ ...selectedTask, completed: checked as boolean })
                  }
                />
                <label htmlFor="edit-completed" className="text-sm font-medium">
                  Mark as completed
                </label>
              </div>
            </div>
          )}
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleEditTask}
              disabled={!selectedTask?.title}
            >
              Update Task
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}