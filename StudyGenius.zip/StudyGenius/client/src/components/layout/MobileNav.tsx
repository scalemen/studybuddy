import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { UserAvatar } from "@/components/ui/user-avatar";
import { 
  BookOpen, 
  LayoutDashboard, 
  StickyNote, 
  Album, 
  Camera, 
  Search, 
  Gamepad2, 
  LogOut,
  Menu,
  X,
  CalendarCheck
} from "lucide-react";

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  onClick?: () => void;
}

function NavItem({ href, icon, label, active, onClick }: NavItemProps) {
  return (
    <li>
      <Link href={href}>
        <a
          className={cn(
            "flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md",
            active
              ? "bg-primary-50 text-primary-700"
              : "text-gray-700 hover:bg-gray-100"
          )}
          onClick={onClick}
        >
          {icon}
          <span>{label}</span>
        </a>
      </Link>
    </li>
  );
}

export function MobileNav() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { user, logout } = useAuth();

  // Close mobile nav when location changes
  useEffect(() => {
    setIsOpen(false);
  }, [location]);

  // Prevent body scroll when nav is open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }

    return () => {
      document.body.style.overflow = "auto";
    };
  }, [isOpen]);

  return (
    <>
      {/* Mobile navigation header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 bg-white border-b border-gray-200 z-10">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-md bg-primary-600 flex items-center justify-center">
              <BookOpen className="text-white h-5 w-5" />
            </div>
            <h1 className="font-display font-bold text-xl text-primary-700">StudyBuddy</h1>
          </div>
          <button 
            onClick={() => setIsOpen(true)} 
            className="p-2 rounded-md text-gray-500 hover:bg-gray-100"
          >
            <Menu className="h-6 w-6" />
          </button>
        </div>
      </div>

      {/* Mobile Navigation Backdrop */}
      {isOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-gray-600 bg-opacity-75 z-20"
          onClick={() => setIsOpen(false)}
        ></div>
      )}

      {/* Mobile Navigation Drawer */}
      <div 
        className={cn(
          "lg:hidden fixed inset-y-0 left-0 w-full max-w-xs bg-white z-30 transform transition-transform duration-300 ease-in-out",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="h-full flex flex-col">
          <div className="p-4 flex items-center justify-between border-b border-gray-200">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-md bg-primary-600 flex items-center justify-center">
                <BookOpen className="text-white h-5 w-5" />
              </div>
              <h1 className="font-display font-bold text-xl text-primary-700">StudyBuddy</h1>
            </div>
            <button 
              onClick={() => setIsOpen(false)} 
              className="p-2 rounded-md text-gray-500 hover:bg-gray-100"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
          
          {/* User info */}
          <div className="p-4 flex items-center gap-3 border-b border-gray-100">
            <UserAvatar user={user} className="h-9 w-9" />
            <div className="flex flex-col">
              <span className="text-sm font-medium">{user?.displayName || user?.username}</span>
              <span className="text-xs text-gray-500">{user?.email}</span>
            </div>
          </div>
          
          {/* Mobile navigation links */}
          <nav className="flex-1 overflow-y-auto py-4">
            <ul className="space-y-1 px-3">
              <NavItem 
                href="/dashboard" 
                icon={<LayoutDashboard className="h-5 w-5" />} 
                label="Dashboard" 
                active={location === "/dashboard"} 
                onClick={() => setIsOpen(false)}
              />
              <NavItem 
                href="/notes" 
                icon={<StickyNote className="h-5 w-5" />} 
                label="Notes" 
                active={location === "/notes"} 
                onClick={() => setIsOpen(false)}
              />
              <NavItem 
                href="/flashcards" 
                icon={<Album className="h-5 w-5" />} 
                label="Flashcards" 
                active={location === "/flashcards"} 
                onClick={() => setIsOpen(false)}
              />
              <NavItem 
                href="/homework-helper" 
                icon={<Camera className="h-5 w-5" />} 
                label="Homework Helper" 
                active={location === "/homework-helper"} 
                onClick={() => setIsOpen(false)}
              />
              <NavItem 
                href="/topic-search" 
                icon={<Search className="h-5 w-5" />} 
                label="Topic Search" 
                active={location === "/topic-search"} 
                onClick={() => setIsOpen(false)}
              />
              <NavItem 
                href="/mini-games" 
                icon={<Gamepad2 className="h-5 w-5" />} 
                label="Mini Games" 
                active={location === "/mini-games"} 
                onClick={() => setIsOpen(false)}
              />
              <NavItem 
                href="/study-planner" 
                icon={<CalendarCheck className="h-5 w-5" />} 
                label="Study Planner" 
                active={location === "/study-planner"} 
                onClick={() => setIsOpen(false)}
              />
            </ul>
          </nav>
          
          {/* Bottom section */}
          <div className="p-4 border-t border-gray-200">
            <button 
              onClick={() => logout()} 
              className="flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md text-red-600 hover:bg-red-50 w-full"
            >
              <LogOut className="h-5 w-5" />
              <span>Sign Out</span>
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
