import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/use-auth";
import { UserAvatar } from "@/components/ui/user-avatar";
import { Separator } from "@/components/ui/separator";
import { useQuery } from "@tanstack/react-query";
import { truncateText } from "@/lib/utils";

import {
  BookOpen,
  LayoutDashboard,
  StickyNote,
  Album,
  Camera,
  Search,
  Gamepad2,
  LogOut,
  CalendarCheck
} from "lucide-react";

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  label: string;
  active?: boolean;
}

function NavItem({ href, icon, label, active }: NavItemProps) {
  return (
    <li>
      <Link href={href}>
        <a
          className={cn(
            "flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md",
            active
              ? "bg-primary-50 text-primary-700"
              : "text-gray-700 hover:bg-gray-100"
          )}
        >
          {icon}
          <span>{label}</span>
        </a>
      </Link>
    </li>
  );
}

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const { data: notes } = useQuery({
    queryKey: ['/api/notes'],
    enabled: !!user,
  });

  return (
    <aside className="hidden lg:flex flex-col w-64 border-r border-gray-200 bg-white h-screen">
      <div className="p-4 flex items-center gap-2 border-b border-gray-100">
        <div className="h-8 w-8 rounded-md bg-primary-600 flex items-center justify-center">
          <BookOpen className="text-white h-5 w-5" />
        </div>
        <h1 className="font-display font-bold text-xl text-primary-700">StudyBuddy</h1>
      </div>
      
      {/* User info */}
      <div className="p-4 flex items-center gap-3 border-b border-gray-100">
        <UserAvatar user={user} className="h-9 w-9" />
        <div className="flex flex-col">
          <span className="text-sm font-medium">{user?.displayName || user?.username}</span>
          <span className="text-xs text-gray-500">{user?.email}</span>
        </div>
      </div>
      
      {/* Navigation links */}
      <nav className="flex-1 overflow-y-auto py-4">
        <ul className="space-y-1 px-3">
          <NavItem 
            href="/dashboard" 
            icon={<LayoutDashboard className="h-5 w-5" />} 
            label="Dashboard" 
            active={location === "/dashboard"} 
          />
          <NavItem 
            href="/notes" 
            icon={<StickyNote className="h-5 w-5" />} 
            label="Notes" 
            active={location === "/notes"} 
          />
          <NavItem 
            href="/flashcards" 
            icon={<Album className="h-5 w-5" />} 
            label="Flashcards" 
            active={location === "/flashcards"} 
          />
          <NavItem 
            href="/homework-helper" 
            icon={<Camera className="h-5 w-5" />} 
            label="Homework Helper" 
            active={location === "/homework-helper"} 
          />
          <NavItem 
            href="/topic-search" 
            icon={<Search className="h-5 w-5" />} 
            label="Topic Search" 
            active={location === "/topic-search"} 
          />
          <NavItem 
            href="/mini-games" 
            icon={<Gamepad2 className="h-5 w-5" />} 
            label="Mini Games" 
            active={location === "/mini-games"} 
          />
          <NavItem 
            href="/study-planner" 
            icon={<CalendarCheck className="h-5 w-5" />} 
            label="Study Planner" 
            active={location === "/study-planner"} 
          />
        </ul>
        
        {notes && notes.length > 0 && (
          <div className="mt-6 px-3">
            <h2 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">Recent Notes</h2>
            <ul className="mt-2 space-y-1">
              {notes.slice(0, 3).map((note: any) => (
                <li key={note.id}>
                  <Link href={`/notes/${note.id}`}>
                    <a className="flex items-center gap-2 px-3 py-2 text-sm rounded-md text-gray-700 hover:bg-gray-100 truncate">
                      <StickyNote className="h-4 w-4 text-gray-500" />
                      <span>{truncateText(note.title, 25)}</span>
                    </a>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}
      </nav>
      
      {/* Bottom section */}
      <div className="p-4 border-t border-gray-200">
        <button 
          onClick={() => logout()} 
          className="flex items-center gap-2 px-3 py-2 text-sm font-medium rounded-md text-red-600 hover:bg-red-50 w-full"
        >
          <LogOut className="h-5 w-5" />
          <span>Sign Out</span>
        </button>
      </div>
    </aside>
  );
}
