import { Sidebar } from "./Sidebar";
import { MobileNav } from "./MobileNav";
import { ReactNode } from "react";

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  return (
    <div className="flex h-screen overflow-hidden">
      {/* Sidebar for desktop */}
      <Sidebar />
      
      {/* Mobile navigation */}
      <MobileNav />
      
      {/* Main content area */}
      <main className="flex-1 overflow-y-auto pt-0 lg:pt-0 pb-16 lg:pb-0">
        <div className="lg:pt-0 pt-16 animate-fade-in px-4 py-6 sm:px-6 lg:px-8 pb-24">
          {children}
        </div>
      </main>
    </div>
  );
}
