import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Clock, Calculator, BarChart2, Trophy } from "lucide-react";

type Difficulty = "easy" | "medium" | "hard";
type Operation = "+" | "-" | "×" | "÷";

interface Problem {
  num1: number;
  num2: number;
  operation: Operation;
  answer: number;
}

export default function MathChallenge() {
  const [difficulty, setDifficulty] = useState<Difficulty>("easy");
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(60);
  const [currentProblem, setCurrentProblem] = useState<Problem | null>(null);
  const [userAnswer, setUserAnswer] = useState("");
  const [problems, setProblems] = useState<Problem[]>([]);
  const [currentProblemIndex, setCurrentProblemIndex] = useState(0);
  const [showResults, setShowResults] = useState(false);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  
  const inputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  
  // Generate a single problem based on difficulty
  const generateProblem = (difficulty: Difficulty): Problem => {
    let num1, num2, operation, answer;
    const operations: Operation[] = ["+", "-", "×", "÷"];
    
    // Select operations based on difficulty
    let availableOperations: Operation[];
    if (difficulty === "easy") {
      availableOperations = ["+", "-"];
    } else if (difficulty === "medium") {
      availableOperations = ["+", "-", "×"];
    } else {
      availableOperations = operations;
    }
    
    // Select random operation
    operation = availableOperations[Math.floor(Math.random() * availableOperations.length)];
    
    // Generate numbers based on difficulty and operation
    switch (operation) {
      case "+":
        if (difficulty === "easy") {
          num1 = Math.floor(Math.random() * 10) + 1; // 1-10
          num2 = Math.floor(Math.random() * 10) + 1; // 1-10
        } else if (difficulty === "medium") {
          num1 = Math.floor(Math.random() * 50) + 1; // 1-50
          num2 = Math.floor(Math.random() * 50) + 1; // 1-50
        } else {
          num1 = Math.floor(Math.random() * 100) + 1; // 1-100
          num2 = Math.floor(Math.random() * 100) + 1; // 1-100
        }
        answer = num1 + num2;
        break;
      case "-":
        if (difficulty === "easy") {
          num2 = Math.floor(Math.random() * 10) + 1; // 1-10
          num1 = num2 + Math.floor(Math.random() * 10); // ensure num1 > num2
        } else if (difficulty === "medium") {
          num2 = Math.floor(Math.random() * 50) + 1; // 1-50
          num1 = num2 + Math.floor(Math.random() * 50); // ensure num1 > num2
        } else {
          num2 = Math.floor(Math.random() * 100) + 1; // 1-100
          num1 = num2 + Math.floor(Math.random() * 100); // ensure num1 > num2
        }
        answer = num1 - num2;
        break;
      case "×":
        if (difficulty === "medium") {
          num1 = Math.floor(Math.random() * 10) + 1; // 1-10
          num2 = Math.floor(Math.random() * 10) + 1; // 1-10
        } else {
          num1 = Math.floor(Math.random() * 12) + 1; // 1-12
          num2 = Math.floor(Math.random() * 12) + 1; // 1-12
        }
        answer = num1 * num2;
        break;
      case "÷":
        if (difficulty === "hard") {
          num2 = Math.floor(Math.random() * 10) + 1; // 1-10
          num1 = num2 * (Math.floor(Math.random() * 10) + 1); // ensure clean division
          answer = num1 / num2;
        }
        break;
      default:
        num1 = 0;
        num2 = 0;
        answer = 0;
    }
    
    return { num1, num2, operation, answer };
  };
  
  // Generate a batch of problems
  const generateProblems = (count: number): Problem[] => {
    const problems: Problem[] = [];
    for (let i = 0; i < count; i++) {
      problems.push(generateProblem(difficulty));
    }
    return problems;
  };
  
  // Start the game
  const startGame = () => {
    const newProblems = generateProblems(10);
    setProblems(newProblems);
    setCurrentProblem(newProblems[0]);
    setCurrentProblemIndex(0);
    setScore(0);
    setTimeRemaining(60);
    setGameStarted(true);
    setGameOver(false);
    setShowResults(false);
    setCorrectAnswers(0);
    setUserAnswer("");
    
    // Focus on input field
    setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }, 100);
  };
  
  // Check the user's answer
  const checkAnswer = () => {
    if (!currentProblem) return;
    
    const userNum = parseInt(userAnswer);
    
    // Check if answer is correct
    if (userNum === currentProblem.answer) {
      // Award points based on difficulty
      let points = 0;
      switch (difficulty) {
        case "easy":
          points = 1;
          break;
        case "medium":
          points = 2;
          break;
        case "hard":
          points = 3;
          break;
      }
      
      setScore(score + points);
      setCorrectAnswers(correctAnswers + 1);
      
      toast({
        title: "Correct!",
        description: `+${points} points`,
      });
    } else {
      toast({
        title: "Incorrect",
        description: `The correct answer was ${currentProblem.answer}`,
        variant: "destructive"
      });
    }
    
    // Move to next problem or end game
    if (currentProblemIndex < problems.length - 1) {
      setCurrentProblemIndex(currentProblemIndex + 1);
      setCurrentProblem(problems[currentProblemIndex + 1]);
      setUserAnswer("");
    } else {
      endGame();
    }
    
    // Focus on input field
    setTimeout(() => {
      if (inputRef.current) {
        inputRef.current.focus();
      }
    }, 100);
  };
  
  // End the game
  const endGame = () => {
    setGameStarted(false);
    setGameOver(true);
    setShowResults(true);
  };
  
  // Handle input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Only allow numbers
    const value = e.target.value.replace(/[^0-9-]/g, "");
    setUserAnswer(value);
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    checkAnswer();
  };
  
  // Timer effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (gameStarted && timeRemaining > 0) {
      timer = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            endGame();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [gameStarted, timeRemaining]);
  
  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Enter" && gameStarted && userAnswer) {
        checkAnswer();
      }
    };
    
    window.addEventListener("keydown", handleKeyDown);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [gameStarted, userAnswer, currentProblem]);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Calculator className="h-5 w-5 text-primary-600" />
              Math Challenge
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-sm">
              <p>Test your math skills by solving a series of problems as quickly as possible!</p>
            </div>
            
            {!gameStarted && !gameOver && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-1">Select Difficulty:</label>
                  <div className="flex space-x-2">
                    <Button 
                      variant={difficulty === "easy" ? "default" : "outline"}
                      onClick={() => setDifficulty("easy")}
                      className="flex-1"
                    >
                      Easy
                    </Button>
                    <Button 
                      variant={difficulty === "medium" ? "default" : "outline"}
                      onClick={() => setDifficulty("medium")}
                      className="flex-1"
                    >
                      Medium
                    </Button>
                    <Button 
                      variant={difficulty === "hard" ? "default" : "outline"}
                      onClick={() => setDifficulty("hard")}
                      className="flex-1"
                    >
                      Hard
                    </Button>
                  </div>
                </div>
                
                <Button onClick={startGame} className="w-full">
                  Start Game
                </Button>
              </div>
            )}
            
            {gameStarted && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span className="text-sm font-medium">Time: {timeRemaining}s</span>
                  </div>
                  <div className="text-sm font-medium">
                    Score: {score}
                  </div>
                </div>
                <Progress value={(timeRemaining / 60) * 100} />
                
                <div className="text-sm text-gray-500">
                  Problem {currentProblemIndex + 1} of {problems.length}
                </div>
              </div>
            )}
            
            {showResults && (
              <div className="space-y-3">
                <div className="text-center">
                  <Trophy className="h-10 w-10 text-amber-500 mx-auto mb-2" />
                  <h3 className="text-xl font-bold">Game Over!</h3>
                  <p className="text-gray-600">Final Score: {score}</p>
                </div>
                
                <div className="bg-gray-50 p-3 rounded-md">
                  <div className="text-sm text-gray-600 flex justify-between">
                    <span>Problems Solved:</span>
                    <span>{correctAnswers} / {problems.length}</span>
                  </div>
                  <div className="text-sm text-gray-600 flex justify-between">
                    <span>Accuracy:</span>
                    <span>{Math.round((correctAnswers / problems.length) * 100)}%</span>
                  </div>
                </div>
                
                <Button onClick={startGame} className="w-full">
                  Play Again
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card className="md:col-span-2">
          {gameStarted && currentProblem && (
            <CardContent className="pt-6">
              <div className="flex flex-col items-center justify-center">
                <div className="text-4xl font-bold mb-8 flex items-center justify-center gap-4">
                  <span>{currentProblem.num1}</span>
                  <span className="text-primary-600">{currentProblem.operation}</span>
                  <span>{currentProblem.num2}</span>
                  <span>=</span>
                  <span>?</span>
                </div>
                
                <form onSubmit={handleSubmit} className="w-full max-w-md">
                  <div className="flex gap-2">
                    <input
                      ref={inputRef}
                      type="text"
                      inputMode="numeric"
                      className="flex-1 p-4 text-center text-2xl border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                      value={userAnswer}
                      onChange={handleInputChange}
                      placeholder="Enter answer"
                      autoFocus
                    />
                    <Button type="submit" disabled={!userAnswer} size="lg">
                      Submit
                    </Button>
                  </div>
                </form>
                
                <div className="mt-6 text-sm text-center text-gray-500">
                  Press Enter to submit your answer
                </div>
              </div>
            </CardContent>
          )}
          
          {(!gameStarted && !gameOver) && (
            <CardContent className="pt-6">
              <div className="bg-gray-50 rounded-lg p-6 text-center">
                <BarChart2 className="h-16 w-16 text-primary-500 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-900 mb-2">Difficulty Levels</h3>
                <div className="space-y-4 max-w-md mx-auto mt-4 text-left">
                  <div className="bg-white p-3 rounded-md shadow-sm">
                    <h4 className="font-medium text-primary-700">Easy</h4>
                    <p className="text-sm text-gray-600">Addition and subtraction with numbers 1-10</p>
                  </div>
                  <div className="bg-white p-3 rounded-md shadow-sm">
                    <h4 className="font-medium text-primary-700">Medium</h4>
                    <p className="text-sm text-gray-600">Addition, subtraction, and multiplication with numbers 1-50</p>
                  </div>
                  <div className="bg-white p-3 rounded-md shadow-sm">
                    <h4 className="font-medium text-primary-700">Hard</h4>
                    <p className="text-sm text-gray-600">All operations, including division, with larger numbers</p>
                  </div>
                </div>
              </div>
            </CardContent>
          )}
          
          {showResults && (
            <CardContent className="pt-6">
              <div className="text-center">
                <h3 className="text-xl font-medium mb-4">Your Results</h3>
                <div className="max-w-md mx-auto grid grid-cols-2 gap-4">
                  {problems.map((problem, index) => (
                    <div 
                      key={index}
                      className={`p-3 rounded-md border ${
                        index < currentProblemIndex
                          ? `bg-${index < correctAnswers ? 'green' : 'red'}-50 border-${index < correctAnswers ? 'green' : 'red'}-200`
                          : 'bg-gray-50 border-gray-200'
                      }`}
                    >
                      <div className="text-sm">
                        {problem.num1} {problem.operation} {problem.num2} = {problem.answer}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          )}
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Benefits of Math Games</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <h3 className="font-medium">Improve Mental Calculation</h3>
              <p className="text-sm text-gray-600">Regular practice helps you perform calculations more quickly and accurately without relying on calculators.</p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Build Number Sense</h3>
              <p className="text-sm text-gray-600">Understanding how numbers relate to each other is fundamental for all areas of mathematics.</p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Boost Confidence</h3>
              <p className="text-sm text-gray-600">As your skills improve, you'll gain confidence in your mathematical abilities and approach problems with less anxiety.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
