import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Check, X, Lightbulb, RefreshCw, Trophy } from "lucide-react";

// Puzzle types
type RiddlePuzzle = {
  type: "riddle";
  question: string;
  answer: string;
  hint: string;
};

type LogicPuzzle = {
  type: "logic";
  scenario: string;
  options: string[];
  correctIndex: number;
  explanation: string;
};

type SequencePuzzle = {
  type: "sequence";
  instruction: string;
  sequence: number[];
  nextNumber: number;
  explanation: string;
};

type Puzzle = RiddlePuzzle | LogicPuzzle | SequencePuzzle;

// Sample puzzles database
const puzzles: Puzzle[] = [
  {
    type: "riddle",
    question: "I'm tall when I'm young, and I'm short when I'm old. What am I?",
    answer: "A candle",
    hint: "I provide light and melt over time."
  },
  {
    type: "riddle",
    question: "What has keys but no locks, space but no room, and you can enter but not go in?",
    answer: "A keyboard",
    hint: "You use me to type."
  },
  {
    type: "logic",
    scenario: "A farmer needs to cross a river with a fox, a chicken, and a sack of grain. The boat can only carry the farmer and one item. If left alone, the fox will eat the chicken, and the chicken will eat the grain. How can the farmer get everything across?",
    options: [
      "Take the fox first, then return and take the chicken, bring back the fox, take the grain, and finally go back for the fox.",
      "Take the chicken first, then return and take the fox, bring back the chicken, take the grain, and finally go back for the chicken.",
      "Take the grain first, then return and take the chicken, bring back the grain, take the fox, and finally go back for the grain.",
      "It's impossible to get everything across safely."
    ],
    correctIndex: 1,
    explanation: "Take the chicken first (fox and grain are safe together). Return alone. Take the fox over, bring the chicken back. Take the grain over (fox and grain are safe). Return alone and take the chicken over."
  },
  {
    type: "sequence",
    instruction: "What number comes next in this sequence?",
    sequence: [2, 4, 8, 16, 32],
    nextNumber: 64,
    explanation: "Each number is doubled to get the next number in the sequence."
  },
  {
    type: "sequence",
    instruction: "Find the next number in the pattern:",
    sequence: [1, 4, 9, 16, 25],
    nextNumber: 36,
    explanation: "These are perfect squares: 1², 2², 3², 4², 5², so the next is 6² = 36."
  }
];

export default function BrainTeaser() {
  const [currentPuzzleIndex, setCurrentPuzzleIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [selectedOptionIndex, setSelectedOptionIndex] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [score, setScore] = useState(0);
  const [puzzlesSolved, setPuzzlesSolved] = useState(0);
  
  const { toast } = useToast();
  
  const currentPuzzle = puzzles[currentPuzzleIndex];
  
  const checkAnswer = () => {
    let correct = false;
    
    if (currentPuzzle.type === "riddle") {
      // Check if the answer contains the correct keywords (case insensitive)
      correct = userAnswer.toLowerCase().includes(currentPuzzle.answer.toLowerCase());
    } else if (currentPuzzle.type === "logic" && selectedOptionIndex !== null) {
      correct = selectedOptionIndex === currentPuzzle.correctIndex;
    } else if (currentPuzzle.type === "sequence") {
      correct = parseInt(userAnswer) === currentPuzzle.nextNumber;
    }
    
    setIsCorrect(correct);
    setShowAnswer(true);
    
    if (correct) {
      setScore(score + 10);
      setPuzzlesSolved(puzzlesSolved + 1);
      toast({
        title: "Correct!",
        description: "Great job solving this puzzle!",
      });
    } else {
      toast({
        title: "Not quite right",
        description: "Take another look or check the answer.",
        variant: "destructive"
      });
    }
  };
  
  const nextPuzzle = () => {
    setCurrentPuzzleIndex((prev) => (prev + 1) % puzzles.length);
    resetPuzzle();
  };
  
  const resetPuzzle = () => {
    setUserAnswer("");
    setSelectedOptionIndex(null);
    setShowAnswer(false);
    setShowHint(false);
    setIsCorrect(null);
  };
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-amber-500" />
              Your Score
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-4xl font-bold text-primary-600">{score}</div>
            <p className="text-sm text-gray-500 mt-1">Puzzles solved: {puzzlesSolved}</p>
          </CardContent>
        </Card>
        
        <Card className="md:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle>Brain Teaser Challenge</CardTitle>
            <CardDescription>
              Solve puzzles to improve your logical reasoning and critical thinking skills
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="puzzle" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="puzzle">Puzzle</TabsTrigger>
                <TabsTrigger value="hint" disabled={!showHint && !showAnswer}>Hint</TabsTrigger>
                <TabsTrigger value="solution" disabled={!showAnswer}>Solution</TabsTrigger>
              </TabsList>
              <TabsContent value="puzzle" className="py-4">
                {currentPuzzle.type === "riddle" && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Riddle</h3>
                    <p className="text-gray-700">{currentPuzzle.question}</p>
                    <div className="space-y-2">
                      <label htmlFor="answer" className="block text-sm font-medium">
                        Your Answer
                      </label>
                      <input
                        type="text"
                        id="answer"
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                        placeholder="Enter your answer..."
                        value={userAnswer}
                        onChange={(e) => setUserAnswer(e.target.value)}
                        disabled={showAnswer}
                      />
                    </div>
                  </div>
                )}
                
                {currentPuzzle.type === "logic" && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Logic Problem</h3>
                    <p className="text-gray-700">{currentPuzzle.scenario}</p>
                    <div className="space-y-2">
                      {currentPuzzle.options.map((option, index) => (
                        <div
                          key={index}
                          className={`p-3 border rounded-md cursor-pointer ${
                            selectedOptionIndex === index 
                              ? 'border-primary-500 bg-primary-50' 
                              : 'border-gray-300 hover:bg-gray-50'
                          } ${showAnswer ? 'pointer-events-none' : ''}`}
                          onClick={() => !showAnswer && setSelectedOptionIndex(index)}
                        >
                          <div className="flex items-start gap-2">
                            <div className={`flex-shrink-0 h-5 w-5 rounded-full border ${
                              selectedOptionIndex === index 
                                ? 'border-primary-500' 
                                : 'border-gray-300'
                            } flex items-center justify-center`}>
                              {selectedOptionIndex === index && (
                                <div className="h-3 w-3 rounded-full bg-primary-500"></div>
                              )}
                            </div>
                            <span className="text-gray-700">{option}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {currentPuzzle.type === "sequence" && (
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Number Sequence</h3>
                    <p className="text-gray-700">{currentPuzzle.instruction}</p>
                    <div className="flex flex-wrap items-center gap-3 my-4">
                      {currentPuzzle.sequence.map((num, index) => (
                        <div key={index} className="h-10 w-10 flex items-center justify-center rounded-md bg-primary-100 text-primary-700 font-medium">
                          {num}
                        </div>
                      ))}
                      <div className="h-10 w-10 flex items-center justify-center rounded-md border-2 border-dashed border-gray-300 text-gray-500">
                        ?
                      </div>
                    </div>
                    <div className="space-y-2">
                      <label htmlFor="sequence-answer" className="block text-sm font-medium">
                        Next Number
                      </label>
                      <input
                        type="number"
                        id="sequence-answer"
                        className="w-full p-2 border border-gray-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
                        placeholder="Enter the next number..."
                        value={userAnswer}
                        onChange={(e) => setUserAnswer(e.target.value)}
                        disabled={showAnswer}
                      />
                    </div>
                  </div>
                )}
              </TabsContent>
              
              <TabsContent value="hint" className="py-4">
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-md">
                  <div className="flex items-start gap-2">
                    <Lightbulb className="h-5 w-5 text-amber-500 flex-shrink-0 mt-0.5" />
                    <div>
                      <h3 className="font-medium text-amber-800 mb-1">Hint</h3>
                      <p className="text-amber-700">
                        {currentPuzzle.type === "riddle" 
                          ? currentPuzzle.hint 
                          : currentPuzzle.type === "logic" 
                            ? "Think step by step about what can and cannot be left alone together."
                            : "Look for a pattern in how each number relates to its position in the sequence."}
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              
              <TabsContent value="solution" className="py-4">
                <div className={`p-4 border rounded-md ${
                  isCorrect ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'
                }`}>
                  <div className="flex items-start gap-2">
                    {isCorrect 
                      ? <Check className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
                      : <X className="h-5 w-5 text-red-500 flex-shrink-0 mt-0.5" />
                    }
                    <div>
                      <h3 className={`font-medium mb-1 ${
                        isCorrect ? 'text-green-800' : 'text-red-800'
                      }`}>
                        {isCorrect ? 'Correct!' : 'Incorrect'}
                      </h3>
                      <p className={isCorrect ? 'text-green-700' : 'text-red-700'}>
                        {currentPuzzle.type === "riddle" 
                          ? `The answer is: ${currentPuzzle.answer}`
                          : currentPuzzle.type === "logic" 
                            ? currentPuzzle.explanation
                            : `The next number is ${currentPuzzle.nextNumber}. ${currentPuzzle.explanation}`
                        }
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
          <CardFooter className="flex justify-between pt-0">
            {!showAnswer ? (
              <>
                <Button 
                  variant="outline" 
                  onClick={() => setShowHint(true)}
                  disabled={showHint}
                >
                  <Lightbulb className="h-4 w-4 mr-2" />
                  Show Hint
                </Button>
                <Button 
                  onClick={checkAnswer}
                  disabled={
                    (currentPuzzle.type === "riddle" && !userAnswer.trim()) ||
                    (currentPuzzle.type === "logic" && selectedOptionIndex === null) ||
                    (currentPuzzle.type === "sequence" && !userAnswer.trim())
                  }
                >
                  Check Answer
                </Button>
              </>
            ) : (
              <>
                <Button 
                  variant="outline" 
                  onClick={resetPuzzle}
                >
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Try Again
                </Button>
                <Button 
                  onClick={nextPuzzle}
                >
                  Next Puzzle
                </Button>
              </>
            )}
          </CardFooter>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Benefits of Brain Teasers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <h3 className="font-medium">Improve Problem-Solving</h3>
              <p className="text-sm text-gray-600">Brain teasers force you to think creatively and consider multiple angles to find a solution.</p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Enhance Critical Thinking</h3>
              <p className="text-sm text-gray-600">Regular practice with logic puzzles strengthens your ability to analyze complex situations.</p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Boost Memory</h3>
              <p className="text-sm text-gray-600">Working through brain teasers helps improve retention and recall of information.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
