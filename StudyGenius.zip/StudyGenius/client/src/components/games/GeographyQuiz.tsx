import { useState, useEffect } from "react";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { Globe, Clock, Map, Trophy } from "lucide-react";

// Types
interface Country {
  name: string;
  capital: string;
  continent: string;
  flagUrl: string;
}

interface Question {
  type: 'capital' | 'country' | 'continent';
  country: Country;
  options: string[];
  correctAnswer: string;
}

// Sample countries data
const countries: Country[] = [
  {
    name: "United States",
    capital: "Washington D.C.",
    continent: "North America",
    flagUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/a/a4/Flag_of_the_United_States.svg/320px-Flag_of_the_United_States.svg.png"
  },
  {
    name: "United Kingdom",
    capital: "London",
    continent: "Europe",
    flagUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/a/ae/Flag_of_the_United_Kingdom.svg/320px-Flag_of_the_United_Kingdom.svg.png"
  },
  {
    name: "France",
    capital: "Paris",
    continent: "Europe",
    flagUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/c/c3/Flag_of_France.svg/320px-Flag_of_France.svg.png"
  },
  {
    name: "Japan",
    capital: "Tokyo",
    continent: "Asia",
    flagUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/9/9e/Flag_of_Japan.svg/320px-Flag_of_Japan.svg.png"
  },
  {
    name: "Brazil",
    capital: "Brasília",
    continent: "South America",
    flagUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/0/05/Flag_of_Brazil.svg/320px-Flag_of_Brazil.svg.png"
  },
  {
    name: "Australia",
    capital: "Canberra",
    continent: "Oceania",
    flagUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/b/b9/Flag_of_Australia.svg/320px-Flag_of_Australia.svg.png"
  },
  {
    name: "South Africa",
    capital: "Pretoria",
    continent: "Africa",
    flagUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/a/af/Flag_of_South_Africa.svg/320px-Flag_of_South_Africa.svg.png"
  },
  {
    name: "Canada",
    capital: "Ottawa",
    continent: "North America",
    flagUrl: "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d9/Flag_of_Canada_%28Pantone%29.svg/320px-Flag_of_Canada_%28Pantone%29.svg.png"
  },
  {
    name: "India",
    capital: "New Delhi",
    continent: "Asia",
    flagUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/4/41/Flag_of_India.svg/320px-Flag_of_India.svg.png"
  },
  {
    name: "Germany",
    capital: "Berlin",
    continent: "Europe",
    flagUrl: "https://upload.wikimedia.org/wikipedia/en/thumb/b/ba/Flag_of_Germany.svg/320px-Flag_of_Germany.svg.png"
  }
];

// Question generator functions
function generateCapitalQuestion(country: Country, allCountries: Country[]): Question {
  const correctAnswer = country.capital;
  let options = [correctAnswer];
  
  // Add 3 random incorrect capitals
  while (options.length < 4) {
    const randomCountry = allCountries[Math.floor(Math.random() * allCountries.length)];
    if (!options.includes(randomCountry.capital) && randomCountry.name !== country.name) {
      options.push(randomCountry.capital);
    }
  }
  
  // Shuffle options
  options = options.sort(() => Math.random() - 0.5);
  
  return {
    type: 'capital',
    country,
    options,
    correctAnswer
  };
}

function generateCountryQuestion(country: Country, allCountries: Country[]): Question {
  const correctAnswer = country.name;
  let options = [correctAnswer];
  
  // Add 3 random incorrect countries
  while (options.length < 4) {
    const randomCountry = allCountries[Math.floor(Math.random() * allCountries.length)];
    if (!options.includes(randomCountry.name) && randomCountry.name !== country.name) {
      options.push(randomCountry.name);
    }
  }
  
  // Shuffle options
  options = options.sort(() => Math.random() - 0.5);
  
  return {
    type: 'country',
    country,
    options,
    correctAnswer
  };
}

function generateContinentQuestion(country: Country, allCountries: Country[]): Question {
  const correctAnswer = country.continent;
  const continents = ["North America", "South America", "Europe", "Asia", "Africa", "Oceania", "Antarctica"];
  let options = [correctAnswer];
  
  // Add random continents excluding the correct one
  while (options.length < 4) {
    const randomContinent = continents[Math.floor(Math.random() * continents.length)];
    if (!options.includes(randomContinent)) {
      options.push(randomContinent);
    }
  }
  
  // Shuffle options
  options = options.sort(() => Math.random() - 0.5);
  
  return {
    type: 'continent',
    country,
    options,
    correctAnswer
  };
}

export default function GeographyQuiz() {
  const [gameStarted, setGameStarted] = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [timeRemaining, setTimeRemaining] = useState(60);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [showCorrectAnswer, setShowCorrectAnswer] = useState(false);
  
  const { toast } = useToast();
  
  // Generate a set of questions
  const generateQuestions = (count: number): Question[] => {
    const newQuestions: Question[] = [];
    const questionTypes = ['capital', 'country', 'continent'];
    
    const shuffledCountries = [...countries].sort(() => Math.random() - 0.5);
    
    for (let i = 0; i < count; i++) {
      const country = shuffledCountries[i % shuffledCountries.length];
      const questionType = questionTypes[i % questionTypes.length] as 'capital' | 'country' | 'continent';
      
      let question: Question;
      switch (questionType) {
        case 'capital':
          question = generateCapitalQuestion(country, countries);
          break;
        case 'country':
          question = generateCountryQuestion(country, countries);
          break;
        case 'continent':
          question = generateContinentQuestion(country, countries);
          break;
      }
      
      newQuestions.push(question);
    }
    
    return newQuestions;
  };
  
  // Start the game
  const startGame = () => {
    const newQuestions = generateQuestions(10);
    setQuestions(newQuestions);
    setCurrentQuestion(newQuestions[0]);
    setCurrentQuestionIndex(0);
    setScore(0);
    setTimeRemaining(60);
    setGameStarted(true);
    setGameOver(false);
    setSelectedAnswer(null);
    setCorrectAnswers(0);
    setShowCorrectAnswer(false);
  };
  
  // End the game
  const endGame = () => {
    setGameStarted(false);
    setGameOver(true);
  };
  
  // Check answer and move to next question
  const checkAnswer = (answer: string) => {
    setSelectedAnswer(answer);
    setShowCorrectAnswer(true);
    
    if (answer === currentQuestion?.correctAnswer) {
      setScore(score + 10);
      setCorrectAnswers(correctAnswers + 1);
      toast({
        title: "Correct!",
        description: "+10 points",
      });
    } else {
      toast({
        title: "Incorrect",
        description: `The correct answer was ${currentQuestion?.correctAnswer}`,
        variant: "destructive"
      });
    }
    
    setTimeout(() => {
      moveToNextQuestion();
    }, 1500);
  };
  
  // Move to the next question
  const moveToNextQuestion = () => {
    setShowCorrectAnswer(false);
    setSelectedAnswer(null);
    
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setCurrentQuestion(questions[currentQuestionIndex + 1]);
    } else {
      endGame();
    }
  };
  
  // Timer effect
  useEffect(() => {
    let timer: NodeJS.Timeout;
    
    if (gameStarted && timeRemaining > 0) {
      timer = setInterval(() => {
        setTimeRemaining((prev) => {
          if (prev <= 1) {
            clearInterval(timer);
            endGame();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    }
    
    return () => {
      if (timer) clearInterval(timer);
    };
  }, [gameStarted, timeRemaining]);
  
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2">
              <Globe className="h-5 w-5 text-blue-600" />
              Geography Quiz
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-sm">
              <p>Test your knowledge of countries, capitals, and continents!</p>
            </div>
            
            {!gameStarted && !gameOver && (
              <Button onClick={startGame} className="w-full">
                Start Quiz
              </Button>
            )}
            
            {gameStarted && (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4 text-gray-500" />
                    <span className="text-sm font-medium">Time: {timeRemaining}s</span>
                  </div>
                  <div className="text-sm font-medium">
                    Score: {score}
                  </div>
                </div>
                <Progress value={(timeRemaining / 60) * 100} />
                
                <div className="text-sm text-gray-500">
                  Question {currentQuestionIndex + 1} of {questions.length}
                </div>
              </div>
            )}
            
            {gameOver && (
              <div className="space-y-3">
                <div className="text-center">
                  <Trophy className="h-10 w-10 text-amber-500 mx-auto mb-2" />
                  <h3 className="text-xl font-bold">Quiz Complete!</h3>
                  <p className="text-gray-600">Final Score: {score}</p>
                </div>
                
                <div className="bg-gray-50 p-3 rounded-md">
                  <div className="text-sm text-gray-600 flex justify-between">
                    <span>Correct Answers:</span>
                    <span>{correctAnswers} / {questions.length}</span>
                  </div>
                  <div className="text-sm text-gray-600 flex justify-between">
                    <span>Accuracy:</span>
                    <span>{Math.round((correctAnswers / questions.length) * 100)}%</span>
                  </div>
                </div>
                
                <Button onClick={startGame} className="w-full">
                  Play Again
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
        
        <Card className="md:col-span-2">
          {gameStarted && currentQuestion && (
            <CardContent className="pt-6">
              <div className="flex flex-col items-center justify-center">
                {currentQuestion.type === 'country' && (
                  <div className="mb-4">
                    <img 
                      src={currentQuestion.country.flagUrl} 
                      alt="Country Flag"
                      className="h-32 w-auto object-contain rounded border border-gray-200"
                    />
                  </div>
                )}
                
                <div className="text-center mb-6">
                  <h3 className="text-lg font-medium mb-2">
                    {currentQuestion.type === 'capital' && (
                      <>What is the capital of {currentQuestion.country.name}?</>
                    )}
                    {currentQuestion.type === 'country' && (
                      <>Which country does this flag belong to?</>
                    )}
                    {currentQuestion.type === 'continent' && (
                      <>On which continent is {currentQuestion.country.name} located?</>
                    )}
                  </h3>
                </div>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full max-w-md">
                  {currentQuestion.options.map((option, index) => (
                    <Button
                      key={index}
                      variant={
                        selectedAnswer === option 
                          ? option === currentQuestion.correctAnswer 
                            ? "default" 
                            : "destructive" 
                          : showCorrectAnswer && option === currentQuestion.correctAnswer 
                            ? "default" 
                            : "outline"
                      }
                      className={
                        selectedAnswer 
                          ? "pointer-events-none" 
                          : ""
                      }
                      onClick={() => !selectedAnswer && checkAnswer(option)}
                    >
                      {option}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          )}
          
          {(!gameStarted && !gameOver) && (
            <CardContent className="pt-6">
              <div className="bg-gray-50 rounded-lg p-6 text-center">
                <Map className="h-16 w-16 text-blue-500 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-900 mb-2">Geography Quiz</h3>
                <p className="text-gray-600 mb-4">
                  Test your knowledge of countries, capitals, and continents around the world!
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-left mt-6">
                  <div className="bg-white p-3 rounded-md shadow-sm">
                    <h4 className="font-medium text-blue-700">Country Flags</h4>
                    <p className="text-sm text-gray-600">Identify countries based on their flags</p>
                  </div>
                  <div className="bg-white p-3 rounded-md shadow-sm">
                    <h4 className="font-medium text-blue-700">Capitals</h4>
                    <p className="text-sm text-gray-600">Name the capital cities of countries</p>
                  </div>
                  <div className="bg-white p-3 rounded-md shadow-sm">
                    <h4 className="font-medium text-blue-700">Continents</h4>
                    <p className="text-sm text-gray-600">Match countries to their correct continents</p>
                  </div>
                </div>
              </div>
            </CardContent>
          )}
          
          {gameOver && (
            <CardContent className="pt-6">
              <div className="text-center">
                <h3 className="text-xl font-medium mb-4">Your Performance</h3>
                <div className="max-w-md mx-auto">
                  <div className="bg-gray-50 p-4 rounded-md mb-4">
                    <h4 className="font-medium text-gray-800 mb-2">Correct Answers: {correctAnswers} / {questions.length}</h4>
                    <Progress value={(correctAnswers / questions.length) * 100} className="h-2 mb-1" />
                    <p className="text-sm text-gray-600">Accuracy: {Math.round((correctAnswers / questions.length) * 100)}%</p>
                  </div>
                  
                  <Button onClick={startGame} className="w-full">
                    Try Again
                  </Button>
                </div>
              </div>
            </CardContent>
          )}
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Benefits of Geography Knowledge</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <h3 className="font-medium">Global Awareness</h3>
              <p className="text-sm text-gray-600">Understanding geography helps you better comprehend world events, international relations, and cultural differences.</p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Spatial Reasoning</h3>
              <p className="text-sm text-gray-600">Geography encourages you to think about how places relate to each other, improving your spatial awareness and navigation skills.</p>
            </div>
            <div className="space-y-2">
              <h3 className="font-medium">Cultural Understanding</h3>
              <p className="text-sm text-gray-600">Learning about different countries builds appreciation for diverse cultures and perspectives around the world.</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}