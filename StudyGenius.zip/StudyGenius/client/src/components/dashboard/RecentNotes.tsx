import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { StickyNote } from "lucide-react";
import { formatDate } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export function RecentNotes() {
  const { data: notes, isLoading } = useQuery({
    queryKey: ['/api/notes'],
  });
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-3">
          <div className="flex justify-between items-center">
            <CardTitle>Recent Notes</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex gap-3 animate-pulse">
                <div className="flex-shrink-0 w-10 h-10 rounded-md bg-gray-200" />
                <div className="min-w-0 flex-1">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2" />
                  <div className="h-3 bg-gray-100 rounded w-1/4" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <CardTitle>Recent Notes</CardTitle>
          <Link href="/notes">
            <Button variant="link" className="text-primary-600 hover:text-primary-700 font-medium h-auto p-0">
              View all
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {notes && notes.length > 0 ? (
          <ul className="divide-y divide-gray-200">
            {notes.slice(0, 3).map((note: any) => (
              <li key={note.id} className="py-3 first:pt-5 last:pb-5 px-5">
                <Link href={`/notes/${note.id}`}>
                  <a className="flex items-start gap-3 hover:bg-gray-50 p-2 rounded-md -mx-2">
                    <div className="flex-shrink-0 w-10 h-10 rounded-md bg-primary-100 flex items-center justify-center">
                      <StickyNote className="h-5 w-5 text-primary-600" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <h3 className="text-sm font-medium text-gray-900 truncate">{note.title}</h3>
                      <p className="text-xs text-gray-500 mt-1">Updated {formatDate(note.updatedAt)}</p>
                    </div>
                  </a>
                </Link>
              </li>
            ))}
          </ul>
        ) : (
          <div className="flex flex-col items-center justify-center py-8 px-4 text-center">
            <StickyNote className="h-10 w-10 text-gray-400 mb-2" />
            <h3 className="text-sm font-medium text-gray-900">No notes yet</h3>
            <p className="mt-1 text-sm text-gray-500">Create your first note to see it here.</p>
            <Link href="/notes">
              <Button className="mt-4">Create Note</Button>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
