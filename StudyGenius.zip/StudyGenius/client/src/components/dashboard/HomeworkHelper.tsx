import { useState } from "react";
import { Link } from "wouter";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { Camera, Upload, ImagePlus } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { uploadHomework } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export function HomeworkHelper() {
  const [file, setFile] = useState<File | null>(null);
  const [title, setTitle] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { mutate, isPending } = useMutation({
    mutationFn: async () => {
      if (!file || !title) {
        throw new Error("Please provide a title and upload an image");
      }
      
      const formData = new FormData();
      formData.append("image", file);
      formData.append("title", title);
      
      return uploadHomework(formData);
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/homeworks'] });
      setFile(null);
      setTitle("");
      toast({
        title: "Homework uploaded",
        description: "Your homework has been analyzed successfully."
      });
    },
    onError: (error: any) => {
      toast({
        title: "Upload failed",
        description: error.message || "An error occurred while processing your homework.",
        variant: "destructive"
      });
    }
  });
  
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutate();
  };

  return (
    <Card>
      <CardHeader className="pb-3 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <CardTitle>Homework Helper</CardTitle>
          <Link href="/homework-helper">
            <Button variant="link" className="text-primary-600 hover:text-primary-700 font-medium h-auto p-0">
              View all
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-5">
        <form onSubmit={handleSubmit} className="flex flex-col items-center justify-center h-64 bg-gray-50 rounded-lg">
          <div className="w-16 h-16 rounded-full bg-primary-100 flex items-center justify-center mb-4">
            <Camera className="h-8 w-8 text-primary-600" />
          </div>
          <h3 className="text-base font-medium text-gray-900">Upload your homework</h3>
          <p className="mt-1 text-sm text-gray-500 max-w-md text-center">
            Take a photo of your assignment or problem and we'll help you solve it step by step.
          </p>
          
          {file ? (
            <div className="mt-4 flex flex-col items-center">
              <div className="text-sm text-gray-700 mb-2">
                Selected: {file.name}
              </div>
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Homework title"
                  className="px-3 py-1 border border-gray-300 rounded text-sm"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
                <Button 
                  type="submit" 
                  size="sm"
                  disabled={isPending || !title}
                >
                  {isPending ? "Processing..." : "Upload"}
                </Button>
              </div>
            </div>
          ) : (
            <div className="mt-4">
              <label htmlFor="file-upload" className="cursor-pointer inline-flex items-center px-4 py-2 border border-gray-300 shadow-sm text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500">
                <ImagePlus className="mr-2 h-4 w-4" />
                Choose file
              </label>
              <input
                id="file-upload"
                type="file"
                className="sr-only"
                accept="image/*"
                onChange={handleFileChange}
              />
            </div>
          )}
        </form>
      </CardContent>
    </Card>
  );
}
