import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export function FlashcardPreview() {
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  
  const { data: decks, isLoading: decksLoading } = useQuery({
    queryKey: ['/api/flashcard-decks'],
  });
  
  const { data: cards, isLoading: cardsLoading } = useQuery({
    queryKey: ['/api/flashcard-decks', decks?.[0]?.id, 'cards'],
    enabled: !!decks && decks.length > 0,
  });
  
  const isLoading = decksLoading || cardsLoading;
  const hasCards = !!cards && cards.length > 0;
  
  const handleFlipCard = () => {
    setIsFlipped(!isFlipped);
  };
  
  const handlePrevious = () => {
    setIsFlipped(false);
    setCurrentCardIndex((prev) => (prev === 0 ? (cards.length - 1) : prev - 1));
  };
  
  const handleNext = () => {
    setIsFlipped(false);
    setCurrentCardIndex((prev) => (prev === cards.length - 1 ? 0 : prev + 1));
  };
  
  if (isLoading) {
    return (
      <Card>
        <CardHeader className="pb-3 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <CardTitle>Your Flashcards</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="p-5">
          <div className="animate-pulse">
            <div className="relative h-48 rounded-lg border border-gray-200 bg-gray-100"></div>
            <div className="mt-4 flex justify-between">
              <div className="h-8 w-20 bg-gray-100 rounded"></div>
              <div className="h-4 w-16 bg-gray-100 rounded"></div>
              <div className="h-8 w-20 bg-gray-100 rounded"></div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-3 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <CardTitle>Your Flashcards</CardTitle>
          <Link href="/flashcards">
            <Button variant="link" className="text-primary-600 hover:text-primary-700 font-medium h-auto p-0">
              View all
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-5">
        {!decks || decks.length === 0 || !hasCards ? (
          <div className="flex flex-col items-center justify-center h-48 text-center">
            <p className="text-gray-500 mb-4">You haven't created any flashcards yet.</p>
            <Link href="/flashcards">
              <Button>Create Flashcards</Button>
            </Link>
          </div>
        ) : (
          <>
            <div 
              className="relative h-48 rounded-lg border border-gray-200 bg-gray-50 flex items-center justify-center group cursor-pointer perspective-1000"
              onClick={handleFlipCard}
            >
              <div 
                className={`absolute inset-0 p-4 flex items-center justify-center backface-hidden transition-all duration-300 ${isFlipped ? 'opacity-0 rotate-y-180' : 'opacity-100'}`}
              >
                <p className="text-center font-medium text-lg">{cards[currentCardIndex].front}</p>
              </div>
              <div 
                className={`absolute inset-0 p-4 flex items-center justify-center backface-hidden transition-all duration-300 ${isFlipped ? 'opacity-100' : 'opacity-0 rotate-y-180'}`}
              >
                <p className="text-center text-gray-700">{cards[currentCardIndex].back}</p>
              </div>
            </div>
            <div className="mt-4 flex justify-between items-center">
              <Button 
                variant="outline"
                size="sm"
                onClick={handlePrevious}
                className="text-gray-700"
              >
                <ChevronLeft className="h-4 w-4 mr-1" /> Previous
              </Button>
              <div className="text-sm text-gray-500">
                Card {currentCardIndex + 1} of {cards.length}
              </div>
              <Button 
                variant="outline"
                size="sm"
                onClick={handleNext}
                className="text-gray-700"
              >
                Next <ChevronRight className="h-4 w-4 ml-1" />
              </Button>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}
