import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Search } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { searchTopic } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

export function SearchTopics() {
  const [searchQuery, setSearchQuery] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { mutate, isPending } = useMutation({
    mutationFn: async () => {
      if (!searchQuery.trim()) {
        throw new Error("Please enter a search topic");
      }
      return searchTopic(searchQuery.trim());
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/topic-searches'] });
      toast({
        title: "Topic summary generated",
        description: "Check the Topic Search page to view the full summary."
      });
      setSearchQuery("");
    },
    onError: (error: any) => {
      toast({
        title: "Search failed",
        description: error.message || "An error occurred while searching for the topic.",
        variant: "destructive"
      });
    }
  });
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    mutate();
  };
  
  const popularTopics = [
    "Photosynthesis",
    "Algebra",
    "World War II",
    "Grammar"
  ];

  return (
    <Card>
      <CardHeader className="pb-3 border-b border-gray-200">
        <CardTitle>Search Topics</CardTitle>
      </CardHeader>
      <CardContent className="p-5">
        <form onSubmit={handleSubmit}>
          <div className="relative rounded-md shadow-sm">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-gray-400" />
            </div>
            <Input
              type="text"
              className="pl-10 pr-12"
              placeholder="Search any topic..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
            <div className="absolute inset-y-0 right-0 flex py-1.5 pr-1.5">
              <Button
                type="submit"
                variant="ghost"
                size="sm"
                className="text-primary-700 hover:bg-primary-100"
                disabled={isPending || !searchQuery.trim()}
              >
                {isPending ? "Searching..." : "Search"}
              </Button>
            </div>
          </div>
        </form>
        
        <div className="mt-4">
          <h3 className="text-xs font-medium text-gray-500 uppercase tracking-wider mb-2">Popular Topics</h3>
          <div className="flex flex-wrap gap-2">
            {popularTopics.map((topic) => (
              <Button
                key={topic}
                variant="outline"
                size="sm"
                className="text-xs"
                onClick={() => {
                  setSearchQuery(topic);
                }}
              >
                {topic}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
