import { Link } from "wouter";
import { BrainCircuit, Calculator, Globe } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const games = [
  {
    id: "brain-teaser",
    title: "Brain Teaser",
    description: "Logic puzzles to sharpen your mind",
    icon: BrainCircuit,
    bgColorClass: "bg-green-100",
    iconColorClass: "text-green-600"
  },
  {
    id: "math-challenge",
    title: "Math Challenge",
    description: "Test your calculation speed",
    icon: Calculator,
    bgColorClass: "bg-purple-100",
    iconColorClass: "text-purple-600"
  },
  {
    id: "geography-quiz",
    title: "Geography Quiz",
    description: "Explore the world's countries",
    icon: Globe,
    bgColorClass: "bg-blue-100",
    iconColorClass: "text-blue-600"
  }
];

export function MiniGames() {
  return (
    <Card>
      <CardHeader className="pb-3 border-b border-gray-200">
        <div className="flex justify-between items-center">
          <CardTitle>Mini Games</CardTitle>
          <Link href="/mini-games">
            <Button variant="link" className="text-primary-600 hover:text-primary-700 font-medium h-auto p-0">
              View all
            </Button>
          </Link>
        </div>
      </CardHeader>
      <CardContent className="p-5">
        <ul className="space-y-3">
          {games.map((game) => {
            const GameIcon = game.icon;
            return (
              <li key={game.id}>
                <Link href={`/mini-games/${game.id}`}>
                  <a className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded-md -mx-2">
                    <div className={`flex-shrink-0 w-10 h-10 rounded-md ${game.bgColorClass} flex items-center justify-center`}>
                      <GameIcon className={`h-5 w-5 ${game.iconColorClass}`} />
                    </div>
                    <div>
                      <h3 className="text-sm font-medium">{game.title}</h3>
                      <p className="text-xs text-gray-500">{game.description}</p>
                    </div>
                  </a>
                </Link>
              </li>
            );
          })}
        </ul>
      </CardContent>
    </Card>
  );
}
