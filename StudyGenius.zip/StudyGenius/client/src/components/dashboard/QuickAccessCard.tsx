import { Link } from "wouter";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface QuickAccessCardProps {
  href: string;
  icon: LucideIcon;
  title: string;
  className?: string;
  bgColorClass?: string;
  iconColorClass?: string;
}

export function QuickAccessCard({
  href,
  icon: Icon,
  title,
  className,
  bgColorClass = "bg-primary-100",
  iconColorClass = "text-primary-600"
}: QuickAccessCardProps) {
  return (
    <Link href={href}>
      <a className={cn(
        "group flex flex-col items-center p-4 bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-all",
        className
      )}>
        <div className={cn(
          "w-12 h-12 rounded-full flex items-center justify-center mb-3 group-hover:opacity-80 transition-colors",
          bgColorClass
        )}>
          <Icon className={cn("h-6 w-6", iconColorClass)} />
        </div>
        <h3 className="font-medium text-center">{title}</h3>
      </a>
    </Link>
  );
}
