import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { User } from "lucide-react";

interface UserAvatarProps {
  user: {
    displayName?: string;
    photoUrl?: string;
    username?: string;
  } | null;
  className?: string;
}

export function UserAvatar({ user, className }: UserAvatarProps) {
  if (!user) {
    return (
      <Avatar className={className}>
        <AvatarFallback>
          <User className="h-4 w-4" />
        </AvatarFallback>
      </Avatar>
    );
  }

  const initials = user.displayName
    ? user.displayName.split(" ").map((n) => n[0]).join("").toUpperCase()
    : user.username
      ? user.username[0].toUpperCase()
      : "U";

  return (
    <Avatar className={className}>
      {user.photoUrl && <AvatarImage src={user.photoUrl} alt={user.displayName || user.username || "User"} />}
      <AvatarFallback>{initials}</AvatarFallback>
    </Avatar>
  );
}
