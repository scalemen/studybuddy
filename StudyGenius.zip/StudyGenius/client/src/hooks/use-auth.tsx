import { 
  createContext, 
  useContext, 
  useState, 
  useEffect, 
  ReactNode 
} from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { loginUser, registerUser, googleAuth, logoutUser } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: number;
  username: string;
  email: string;
  displayName?: string;
  photoUrl?: string;
}

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (username: string, email: string, password: string) => Promise<void>;
  googleLogin: (googleData: any) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { 
    data: authData, 
    isLoading 
  } = useQuery({
    queryKey: ['/api/auth/user'],
    refetchOnWindowFocus: true,
    retry: false,
    staleTime: 5 * 60 * 1000, // 5 minutes
    refetchInterval: 15 * 60 * 1000 // 15 minutes
  });

  const loginMutation = useMutation({
    mutationFn: ({ email, password }: { email: string; password: string }) => 
      loginUser(email, password),
    onSuccess: (data) => {
      queryClient.setQueryData(['/api/auth/user'], { 
        authenticated: true, 
        user: data.user 
      });
      toast({
        title: "Welcome back!",
        description: "You have successfully logged in."
      });
      setLocation("/dashboard");
    },
    onError: (error: any) => {
      toast({
        title: "Login failed",
        description: error.message || "Please check your credentials and try again.",
        variant: "destructive"
      });
    }
  });

  const registerMutation = useMutation({
    mutationFn: ({ username, email, password }: { username: string; email: string; password: string }) => 
      registerUser({ username, email, password }),
    onSuccess: () => {
      toast({
        title: "Registration successful",
        description: "Your account has been created. Please log in."
      });
      setLocation("/login");
    },
    onError: (error: any) => {
      toast({
        title: "Registration failed",
        description: error.message || "Please check your information and try again.",
        variant: "destructive"
      });
    }
  });

  const googleLoginMutation = useMutation({
    mutationFn: (googleData: any) => googleAuth(googleData),
    onSuccess: (data) => {
      queryClient.setQueryData(['/api/auth/user'], { 
        authenticated: true, 
        user: data.user 
      });
      toast({
        title: "Welcome!",
        description: "You have successfully logged in with Google."
      });
      setLocation("/dashboard");
    },
    onError: (error: any) => {
      toast({
        title: "Google login failed",
        description: error.message || "An error occurred during Google sign-in.",
        variant: "destructive"
      });
    }
  });

  const logoutMutation = useMutation({
    mutationFn: logoutUser,
    onSuccess: () => {
      queryClient.setQueryData(['/api/auth/user'], { authenticated: false });
      queryClient.invalidateQueries();
      toast({
        title: "Logged out",
        description: "You have been successfully logged out."
      });
      setLocation("/login");
    },
    onError: (error: any) => {
      toast({
        title: "Logout failed",
        description: error.message || "An error occurred while logging out.",
        variant: "destructive"
      });
    }
  });

  const login = async (email: string, password: string) => {
    await loginMutation.mutateAsync({ email, password });
  };

  const register = async (username: string, email: string, password: string) => {
    await registerMutation.mutateAsync({ username, email, password });
  };

  const googleLogin = async (googleData: any) => {
    await googleLoginMutation.mutateAsync(googleData);
  };

  const logout = async () => {
    await logoutMutation.mutateAsync();
  };

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!isLoading && authData && !authData.authenticated) {
      const currentPath = window.location.pathname;
      if (currentPath !== '/login' && currentPath !== '/register') {
        setLocation('/login');
      }
    }
  }, [authData, isLoading, setLocation]);

  return (
    <AuthContext.Provider
      value={{
        user: authData?.user || null,
        isLoading,
        isAuthenticated: !!authData?.authenticated,
        login,
        register,
        googleLogin,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
