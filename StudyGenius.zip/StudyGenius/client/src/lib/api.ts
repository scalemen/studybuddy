import { apiRequest } from "./queryClient";

export async function loginUser(email: string, password: string) {
  const res = await apiRequest("POST", "/api/auth/login", { email, password });
  return res.json();
}

export async function registerUser(userData: {
  username: string;
  email: string;
  password: string;
}) {
  const res = await apiRequest("POST", "/api/auth/register", userData);
  return res.json();
}

export async function googleAuth(googleData: {
  email: string;
  name: string;
  googleId: string;
  photoUrl: string;
}) {
  const res = await apiRequest("POST", "/api/auth/google", googleData);
  return res.json();
}

export async function logoutUser() {
  const res = await apiRequest("POST", "/api/auth/logout", {});
  return res.json();
}

export async function getCurrentUser() {
  const res = await apiRequest("GET", "/api/auth/user", undefined);
  return res.json();
}

// Notes API
export async function createNote(noteData: { title: string; content: string }) {
  const res = await apiRequest("POST", "/api/notes", noteData);
  return res.json();
}

export async function updateNote(id: number, noteData: { title?: string; content?: string }) {
  const res = await apiRequest("PUT", `/api/notes/${id}`, noteData);
  return res.json();
}

export async function deleteNote(id: number) {
  const res = await apiRequest("DELETE", `/api/notes/${id}`, undefined);
  return res.json();
}

// Flashcards API
export async function createFlashcardDeck(deckData: { title: string; description?: string }) {
  const res = await apiRequest("POST", "/api/flashcard-decks", deckData);
  return res.json();
}

export async function createFlashcard(deckId: number, cardData: { front: string; back: string }) {
  const res = await apiRequest("POST", `/api/flashcard-decks/${deckId}/cards`, cardData);
  return res.json();
}

// Homework Helper API
export async function uploadHomework(formData: FormData) {
  const res = await fetch("/api/homeworks/upload", {
    method: "POST",
    body: formData,
    credentials: "include",
  });
  
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`${res.status}: ${text || res.statusText}`);
  }
  
  return res.json();
}

// Topic Search API
export async function searchTopic(topic: string) {
  const res = await apiRequest("POST", "/api/topic-search", { topic });
  return res.json();
}

// Topic Quiz API
export async function generateTopicQuiz(topic: string, numQuestions: number = 5) {
  const res = await apiRequest("POST", "/api/topic-quiz", { topic, numQuestions });
  return res.json();
}

export async function generateFlashcards(topic: string, count: number = 5) {
  const res = await apiRequest("POST", "/api/generate-flashcards", { topic, count });
  return res.json();
}
